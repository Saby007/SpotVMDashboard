import { Component, OnInit, OnDestroy, NgZone } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SpotScoreService, StreamEvent } from './services/spot-score.service';
import { DashboardConfig, SpotScore } from './models/spot-score.model';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit, OnDestroy {
  config: DashboardConfig | null = null;

  // Form state
  selectedSubscription = '';
  selectedRegion = '';
  selectedFamilies: string[] = [];
  desiredCount = 5;

  // Results
  scores: SpotScore[] = [];
  errors: { batch: string[]; status: number; message: string }[] = [];
  timestamp = '';
  loading = false;
  configLoading = true;

  // View toggle
  activeTab: 'table' | 'heatmap' = 'table';

  // Sort state
  sortColumn = '';
  sortAsc = true;

  // SKU family helpers
  familyKeys: string[] = [];

  // Category & Series filters
  selectedCategory = 'All';
  selectedSeries = 'All';

  // Loading animation
  loadingMessages = [
    { emoji: '🏃', text: 'Racing to grab Spot VMs before someone else does...' },
  ];
  currentLoadingMessage = this.loadingMessages[0];
  private loadingInterval: ReturnType<typeof setInterval> | null = null;
  private abortController: AbortController | null = null;
  private countdownInterval: ReturnType<typeof setInterval> | null = null;

  // Live progress state
  progressStatus = '';
  progressBatch = 0;
  progressTotal = 0;
  progressPercent = 0;
  retryCountdown = 0;
  scoresReceived = 0;

  constructor(private spotService: SpotScoreService, private zone: NgZone) {}

  protected Math = Math;

  ngOnInit(): void {
    this.spotService.getConfig().subscribe({
      next: (cfg) => {
        this.config = cfg;
        this.familyKeys = Object.keys(cfg.skuFamilies);
        this.selectedFamilies = [...this.familyKeys];
        this.desiredCount = cfg.defaultDesiredCount;
        if (cfg.subscriptions.length === 1) {
          this.selectedSubscription = cfg.subscriptions[0].id;
        }
        // Default to centralindia if available
        if (cfg.regions.includes('centralindia')) {
          this.selectedRegion = 'centralindia';
        }
        this.configLoading = false;
      },
      error: (err) => {
        console.error('Failed to load config', err);
        this.configLoading = false;
      }
    });
  }

  /** Distinct categories extracted from family key prefixes */
  get categories(): string[] {
    return ['All', ...new Set(this.familyKeys.map(f => {
      const idx = f.indexOf(' - ');
      return idx >= 0 ? f.substring(0, idx) : f;
    }))];
  }

  /** Series options for the currently selected category */
  get seriesOptions(): string[] {
    const families = this.selectedCategory === 'All'
      ? this.familyKeys
      : this.familyKeys.filter(f => f.startsWith(this.selectedCategory + ' - ') || f === this.selectedCategory);
    return ['All', ...families.map(f => {
      const idx = f.indexOf(' - ');
      return idx >= 0 ? f.substring(idx + 3) : f;
    })];
  }

  /** Family keys filtered by the selected category and series */
  get filteredFamilyKeys(): string[] {
    let filtered = this.familyKeys;
    if (this.selectedCategory !== 'All') {
      filtered = filtered.filter(f => f.startsWith(this.selectedCategory + ' - ') || f === this.selectedCategory);
    }
    if (this.selectedSeries !== 'All') {
      filtered = filtered.filter(f => {
        const idx = f.indexOf(' - ');
        const series = idx >= 0 ? f.substring(idx + 3) : f;
        return series === this.selectedSeries;
      });
    }
    return filtered;
  }

  onCategoryChange(): void {
    this.selectedSeries = 'All';
    this.selectedFamilies = [...this.filteredFamilyKeys];
  }

  onSeriesChange(): void {
    this.selectedFamilies = [...this.filteredFamilyKeys];
  }

  get selectedSkus(): string[] {
    if (!this.config) return [];
    return this.selectedFamilies.flatMap(f => this.config!.skuFamilies[f] || []);
  }

  get canFetch(): boolean {
    return !!this.selectedSubscription && !!this.selectedRegion && this.selectedSkus.length > 0 && !this.loading;
  }



  fetchScores(): void {
    if (!this.canFetch) return;
    this.loading = true;
    this.scores = [];
    this.errors = [];
    this.timestamp = '';
    this.progressStatus = 'Connecting...';
    this.progressBatch = 0;
    this.progressTotal = 0;
    this.progressPercent = 0;
    this.retryCountdown = 0;
    this.scoresReceived = 0;

    this.abortController = this.spotService.streamScores(
      this.selectedSubscription,
      this.selectedRegion,
      this.selectedSkus,
      this.desiredCount,
      (event: StreamEvent) => {
        this.zone.run(() => this.handleStreamEvent(event));
      }
    );
  }

  private handleStreamEvent(event: StreamEvent): void {
    switch (event.type) {
      case 'start':
        this.progressTotal = event.totalBatches || 0;
        this.progressStatus = `Starting — ${event.totalSkus} SKUs in ${event.totalBatches} batches`;
        break;

      case 'batch':
        this.progressBatch = (event.batchIndex || 0) + 1;
        this.progressPercent = Math.round((this.progressBatch / this.progressTotal) * 100);
        this.retryCountdown = 0;
        this.clearCountdown();
        this.progressStatus = `Batch ${this.progressBatch}/${this.progressTotal} — ${(event.skus || []).join(', ')}`;
        break;

      case 'scores':
        this.scoresReceived += event.count || 0;
        if (event.scores) {
          this.scores.push(...event.scores);
        }
        this.progressStatus = `Batch ${this.progressBatch}/${this.progressTotal} — got ${event.count} scores (${this.scoresReceived} total)`;
        break;

      case 'retry':
        this.retryCountdown = event.delaySec || 0;
        this.progressStatus = `⚠ 429 Rate Limited — retry ${event.attempt}/${event.maxRetries} in ${this.retryCountdown}s`;
        this.startCountdown();
        break;

      case 'error':
        this.errors.push({
          batch: event.skus || [],
          status: event.status || 0,
          message: event.message || 'Unknown error'
        });
        this.progressStatus = `❌ Batch ${(event.batchIndex || 0) + 1} failed (${event.status})`;
        break;

      case 'done':
        this.timestamp = event.timestamp || new Date().toISOString();
        this.loading = false;
        this.clearCountdown();
        this.progressStatus = '';
        break;

      case 'fatal':
        this.errors = [{ batch: [], status: 0, message: event.message || 'Request failed' }];
        this.loading = false;
        this.clearCountdown();
        this.progressStatus = '';
        break;
    }
  }

  private startCountdown(): void {
    this.clearCountdown();
    this.countdownInterval = setInterval(() => {
      this.zone.run(() => {
        this.retryCountdown--;
        if (this.retryCountdown > 0) {
          this.progressStatus = this.progressStatus.replace(/in \d+s/, `in ${this.retryCountdown}s`);
        } else {
          this.progressStatus = `Retrying batch ${this.progressBatch}/${this.progressTotal}...`;
          this.clearCountdown();
        }
      });
    }, 1000);
  }

  private clearCountdown(): void {
    if (this.countdownInterval) {
      clearInterval(this.countdownInterval);
      this.countdownInterval = null;
    }
  }

  stopFetch(): void {
    if (this.abortController) {
      this.abortController.abort();
      this.abortController = null;
    }
    this.loading = false;
    this.clearCountdown();
    this.progressStatus = '';
  }

  ngOnDestroy(): void {
    this.stopFetch();
  }

  private startLoadingAnimation(): void {}
  private stopLoadingAnimation(): void {}

  // --- Sorting ---
  sortBy(column: string): void {
    if (this.sortColumn === column) {
      this.sortAsc = !this.sortAsc;
    } else {
      this.sortColumn = column;
      this.sortAsc = true;
    }
  }

  get sortedScores(): SpotScore[] {
    if (!this.sortColumn) return this.scores;
    return [...this.scores].sort((a, b) => {
      const col = this.sortColumn as keyof SpotScore;
      const aVal = a[col];
      const bVal = b[col];
      const cmp = String(aVal ?? '').localeCompare(String(bVal ?? ''));
      return this.sortAsc ? cmp : -cmp;
    });
  }

  // --- Heatmap ---
  get heatmapSkus(): string[] {
    return [...new Set(this.scores.map(s => s.sku))].sort();
  }

  get heatmapZones(): string[] {
    return [...new Set(this.scores.map(s => s.availabilityZone || 'N/A'))].sort();
  }

  getHeatmapScore(sku: string, zone: string): SpotScore | undefined {
    return this.scores.find(s => s.sku === sku && (s.availabilityZone || 'N/A') === zone);
  }

  scoreClass(score: string): string {
    switch (score) {
      case 'High': return 'score-high';
      case 'Medium': return 'score-medium';
      case 'Low': return 'score-low';
      default: return 'score-restricted';
    }
  }

  scoreNumeric(score: string): number {
    switch (score) {
      case 'High': return 3;
      case 'Medium': return 2;
      case 'Low': return 1;
      default: return 0;
    }
  }

  // --- Summary counts ---
  get highCount(): number { return this.scores.filter(s => s.score === 'High').length; }
  get mediumCount(): number { return this.scores.filter(s => s.score === 'Medium').length; }
  get lowCount(): number { return this.scores.filter(s => s.score === 'Low').length; }
  get restrictedCount(): number { return this.scores.filter(s => s.score === 'RestrictedSkuNotAvailable').length; }
  get noQuotaCount(): number { return this.scores.filter(s => !s.isQuotaAvailable).length; }
}
